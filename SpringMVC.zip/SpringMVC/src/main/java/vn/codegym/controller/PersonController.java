package vn.codegym.controller;

import org.springframework.web.bind.annotation.RequestMapping;

@RequestMapping("/person")
public class PersonController {
}
